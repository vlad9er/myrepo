#!/bin/bash
source /home/ec2-user/.bash_profile
cd /home/ec2-user/ca-app
curl localhost:8080